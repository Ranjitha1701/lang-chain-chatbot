Study Assistant Chatbot

1. Project Description

The Study Assistant Chatbot is an AI-powered application designed to help students with their academic studies. It allows students to ask study-related questions and receive simple, clear, and understandable answers.

The chatbot uses Google's Gemini AI model to generate responses and Python to build the application.

2. Objectives

- To help students understand difficult concepts.
- To provide answers to academic questions.
- To make learning easier and faster.
- To provide a simple and interactive study assistant.

3. Technologies Used

- Programming Language: Python
- AI Model: Google Gemini AI
- Framework: LangChain
- Libraries:
  - langchain
  - langchain-google-genai
  - python-dotenv
  - google-genai
- IDE: Visual Studio Code

4. Features

- Accepts study-related questions from students.
- Generates AI-based answers.
- Explains concepts in simple language.
- Provides examples suitable for engineering students.
- Supports continuous question-and-answer interaction.
- Allows users to exit the chatbot.

5. Project Structure

Study_Assistant_Chatbot/
│
├── app.py
├── .env
├── requirements.txt
├── README.md
└── venv/

6. Installation and Execution

1. Install Python.
2. Open the project folder in Visual Studio Code.
3. Create and activate a virtual environment.
4. Install the required libraries:

pip install -r requirements.txt

5. Add the Google Gemini API key to the ".env" file:

GOOGLE_API_KEY=your_api_key

6. Run the application:

python app.py

7. How It Works

1. The student enters a study-related question.
2. The question is received by the Python application.
3. LangChain sends the question to Google's Gemini AI model.
4. Gemini generates an answer.
5. The chatbot displays the answer to the student.

8. Future Enhancements

- Add a graphical user interface.
- Add voice-based question input.
- Provide subject-wise learning support.
- Store previous conversations.
- Add PDF-based question answering.

9. Conclusion

The Study Assistant Chatbot is a useful AI-based learning application that helps students get answers to academic questions. It demonstrates the use of Python, LangChain, and Google Gemini AI in developing an interactive educational application.