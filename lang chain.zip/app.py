
import os
from dotenv import load_dotenv
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_core.prompts import ChatPromptTemplate

# Load API key from .env file
load_dotenv()

api_key = os.getenv("GOOGLE_API_KEY")

if not api_key:
    print("Error: Gemini API key not found in .env!")
    exit()

# Connect to Gemini AI
llm = ChatGoogleGenerativeAI(
    model="gemini-3.8-flash",
    google_api_key=api_key,
    temperature=0.3,
    timeout=30,
    max_retries=0
)

# Create prompt template
prompt = ChatPromptTemplate.from_messages([
    ("system", """You are a friendly Study Assistant.
    Explain concepts in simple language.
    Give clear examples suitable for engineering students.
    Help students understand their subjects."""),
    ("human", "{question}")
])

# Create LangChain chain
chain = prompt | llm

print("\n===================================")
print("     STUDY ASSISTANT CHATBOT")
print("===================================")
print("Ask any study-related question.")
print("Type 'exit' to stop the chatbot.\n")

# Chatbot loop
while True:
    question = input("You: ")

    if question.lower() == "exit":
        print("Thank you for using Study Assistant!")
        break

    if not question.strip():
        print("Please enter a question.\n")
        continue

    try:
        response = chain.invoke({"question": question})

        print("\nAI Answer:\n")

        if isinstance(response, list):
            for item in response:
                if item.get("type") == "text":
                    print(item.get("text", ""))
        else:
            print(response.content if hasattr(response, "content") else response)

        print("\n")

    except Exception as e:
        print("Error:", e)
        print("Please try again.\n")

